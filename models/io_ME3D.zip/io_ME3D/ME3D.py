#!BPY
#
# GRAFGEAR ME3D IMPORT-EXPORT FOR BLENDER 2.7X->
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) 2017 Niko Kauppi (Niko40)


# General info
# This file consists one mesh to be used in a game engine data is saved
# plainly without padding, this file uses made up .me3d file extension
# which stands for simple MEsh 3D.
#
# Main feature of this file is that it packs vertex data into a
# list of unique vertices and a list of copy vertices.
# Copy vertices are vertices that share location and normal data with some unique vertex but have
# custom uv or material data. This is less of a feature to save space but more of a
# feature to enable game engines know where they should copy vertex locations to
# prevent ripping of the mesh or skip the location calculations completely and
# just copy the vertex locations.
#
# ::
# file structure:
# 
# header:
#   Basic file header, telling where everything is in the file
#   file header is always 16 integers or 64 bytes
#   ::
#   file_id             # file id string int 32 ( converts to char 8 * 4 )
#   file_head_size      # file header size, should equal to 64 bytes
#   file_size           # file size, used to check file integrity
#   vert_count          # amount of vertices
#   vert_size           # size of a single vertex in bytes
#   vert_location       # vertex data location start in file, usually right after the header
#   vert_copy_count     # amount of copy vertices, these are vertices that share position data
#   vert_copy_size      # size of the copy vertex in file, in bytes
#   vert_copy_location  # file location of the start of the copy vertices list
#   polygon_count       # amount of polygons
#   polygon_size        # size of a single polygon in bytes
#   polygon_location    # file location of the start of the polygon list
#   ( reserved )
#   ( reserved )
#   ( reserved )
#   ( reserved )
#
# vertex data:
#   This is the vertex data, this is all the vertices you see in the mesh
#   inside blender's viewport. Notice that the total amount of vertices
#   you will eventually need is header.vertices + header.copy_vertices but this list
#   is only as long as header.vertices tells you. Also normals and uv coords
#   are only 16 bit shorts and the range of of those are from -32767 to 32767
#   ::
#   location            # vertex location   3 float
#   normal              # vertex normals    3 short
#   uv                  # vertex uv coords  2 short
#   material            # material index    1 short
#
# vertex copy data:
#   This also contains vertex data but in a bit different format.
#   You must not skip these vertices as the polygon data will depend
#   on these. This packs the data slightly. A copy vertex will tell you
#   the initial vertex index where you should copy the data from, then just
#   use a new uv and material. This list also comes handy in a form of an
#   update list. This is that you can use the first vertices for
#   example bone animations, and when you're done moving the vertices
#   you can simply copy thise vertices into the original ones location
#   ::
#   copyfrom            # vertex id to initially copy the data from.    1 int
#   uv                  # introduces new uv data                        2 short
#   material            # introduces new material index                 1 short
#
# polygon data:
#   Basic indices data and tells the vertices it needs to connec to in order
#   to form a triangle. Indices go from 0 to header.vertices + header.copy_vertices
#   ::
#   vertices            # vertices this polygon should connect to       3 int
#
# padding:
#   To prevent overreading the file
#   ::
#   padding             # basic padding, just in case       2 int


# Settings
NEW_VERTEX_UV_TOLERANCE     = 0.001
HEADER_SIZE_BYTES           = 64

DEBUG_CREATE_POINT_MESH     = False
DEBUG_SHOW_TIMES            = True
DEBUG_SHOW_MESSAGES         = True


# import all the needed modules
import time
import struct
import bpy
import math

# Set up some constants
# this magic number translates into human readable text 'ME3D'
STRING_ME3D                     = 1144210765
# Maximum value of signed short
# this will be mapped between -1.0 to +1.0
SHORT_CONVERT_VALUE             = 32767

PI                              = 3.14159265358979323846

FAILURE                         = 0
SUCCESS                         = 1

# Classes used to store data inside Exporter function
class Vertex:
    def __init__( self ):
        self.is_set             = False             # NOT STORED, only used to speed up this script
        self.location           = [0.0, 0.0, 0.0]   # 3 float
        self.normal             = [0.0, 0.0, 0.0]   # 3 short
        self.uv                 = [0.0, 0.0]        # 2 short
        self.mat                = 0                 # 1 short

class VertexCopy:
    def __init__( self ):
        self.copyfrom           = 0                 # 1 int
        self.uv                 = [0.0, 0.0]        # 2 short
        self.mat                = 0                 # 1 short

class Polygon:
    def __init__( self ):
        self.vertices           = [0, 0, 0]         # 3 int


class FileHeader:
    def __init__( self ):
        self.file_id            = 0     # file id string ( converts to char 8 * 4 )
        self.head_size          = 0     # header size
        self.file_size          = 0     # file size
        
        self.vert_count         = 0     # amount of vertices
        self.vert_size          = 0     # size of a single vertex in file
        self.vert_location      = 0     # vertices start location in file
        
        self.copy_count         = 0     # amount of copy vertices
        self.copy_size          = 0     # size of a single vertex copy in file
        self.copy_location      = 0     # copy vertices start location in file
        
        self.poly_count         = 0     # amount of polygons
        self.poly_size          = 0     # size of a single polygon in file
        self.poly_location      = 0     # polygon start location in file

def ExportME3D( context, object, filepath, up_axis, uv_axis ):
    """ Export to ME3D mesh """
    
    print( "--- MESH EXPORTER BEGIN ---" )
    
    time_total = time.clock()
    
    global NEW_VERTEX_UV_TOLERANCE
    global HEADER_SIZE_BYTES
    
    global DEBUG_CREATE_POINT_MESH
    global DEBUG_SHOW_TIMES
    
    global STRING_ME3D
    global SHORT_CONVERT_VALUE
    
    global PI
    
    global SUCCESS
    global FAILURE
    
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    # collect previously selected and active objects
    previous_active_object  = object
    previous_objects        = []
    for o in context.selected_objects:
        previous_objects.append( o )
    
    # create a new object and mesh for it, link the object to the scene,
    # link is needed to be able to use bpy.ops...
    copyobj         = object.copy()
    copymesh        = object.data.copy()
    copyobj.data    = copymesh
    context.scene.objects.link( copyobj )

    # select our new object and only our new object
    bpy.ops.object.select_all( action='DESELECT' )
    copyobj.select                  = True
    context.scene.objects.active    = copyobj
    
    # rotate our new object if necessary
    if up_axis in '+Y':
        copyobj.rotation_euler[0]   = -PI / 2
        copyobj.rotation_euler[1]   = PI
        print( "+Y Axis Up" )
    if up_axis in '-Y':
        copyobj.rotation_euler[0]   = PI / 2
        print( "-Y Axis Up" )
    
    # apply the rotation and scale, create triangulate modifier and create
    # a final mesh we'll be working with, applying modifiers at the same time
    bpy.ops.object.transform_apply( rotation=True, scale=True )
    copyobj.modifiers.new( "Triangulate", 'TRIANGULATE' )
    mesh            = copyobj.to_mesh( bpy.context.scene, True, 'PREVIEW' )
    
    # Set up some useful variables
    vertex_count    = len( mesh.vertices )
    polygon_count   = len( mesh.polygons )
    
    time_alloc = time.clock()
    
    # Allocate space for the vertex list and fill it with Vertex objects
    vertex_list = [None] * vertex_count
    for i in range( 0, vertex_count ):
        vertex_list[i] = Vertex()
    
    polygon_list = [None] * polygon_count
    for i in range( 0, polygon_count ):
        polygon_list[i] = Polygon()
    
    # this list is reserved for the vertex copies, copies are needed
    # in areas where there are different uv coordinates or materials
    vertex_copy_list = []
    vertex_copy_index = 0
    
    time_alloc = time.clock() - time_alloc
    
    time_parse = time.clock()
    
    # go through all the polygons the mesh has
    for polygon_index in range(0, len(mesh.polygons)):
        polygon             = mesh.polygons[polygon_index]
        polygon_uv_index    = 3 * polygon_index
        
        # here we go through the vertices the polygon has, this format only supports trianges
        for polygon_vertex_index in range(0, 3):
            vertex_index            = polygon.vertices[polygon_vertex_index]
            vertex                  = mesh.vertices[vertex_index]
            vertex_uv_index         = polygon_uv_index + polygon_vertex_index
            vertex_uv_loop          = mesh.uv_layers[0].data[vertex_uv_index]
            
            vertex_co               = vertex.undeformed_co
            vertex_norm             = vertex.normal
            vertex_uv               = vertex_uv_loop.uv
            vertex_mat              = polygon.material_index
            
            # Check if the vertex is already set in the list
            if not vertex_list[vertex_index].is_set:
                # The vertex is not on the list yet, so we can just quickly add it there,
                # this operation is fast but happens rarely as polygons tend to share vertices a lot
                vertex_list[vertex_index].is_set        = True
                vertex_list[vertex_index].location      = vertex_co
                vertex_list[vertex_index].normal        = vertex_norm
                vertex_list[vertex_index].uv            = vertex_uv
                vertex_list[vertex_index].mat           = vertex_mat
                polygon_list[polygon_index].vertices[polygon_vertex_index] = vertex_index
            
            else:
                # the vertex we want to add is already set the list, compare values and determine
                # if we can use an already existing vertex or if we need to make a copy vertex
                need_copy = False
                if CheckNeedForCopy( 2, vertex_list[vertex_index].uv, vertex_uv, NEW_VERTEX_UV_TOLERANCE ):
                    need_copy = True
                if vertex_list[vertex_index].mat != vertex_mat:
                    need_copy = True
                
                # check if we determined that a copy vertex is needed
                if need_copy:
                    # in case the vertex was found in the regular vertex list but has
                    # attributes that differ in other ways, we make a new vertex copy
                    similar_found = -1
                    for copy_index in range( 0, len( vertex_copy_list ) ):
                        copy = vertex_copy_list[copy_index]
                        similarities = 0
                        if vertex_index == copy.copyfrom:
                            if CheckNeedForCopy( 2, copy.uv, vertex_uv, NEW_VERTEX_UV_TOLERANCE ) == False:
                                similarities += 1
                            if copy.mat == vertex_mat:
                                similarities += 1
                            if similarities >= 2:
                                similar_found = vertex_index
                                break
                    
                    # we need a copy vertex but we might already have a similar vertex
                    # in a copy vertex list, if that's the case we can just use that one
                    if -1 == similar_found:
                        # new copy vertex needed, add it to the copy list and set up the polygon order
                        # this means that a vertex has a shared location with a previously existing
                        # vertex but has different uv coordinates or material index, we need a new copy vertex
                        new_vertex_index = vertex_count + vertex_copy_index
                        polygon_list[polygon_index].vertices[polygon_vertex_index] = new_vertex_index
                        vertex_copy_list.append( VertexCopy() )
                        vertex_copy_list[vertex_copy_index].copyfrom    = vertex_index
                        vertex_copy_list[vertex_copy_index].uv          = vertex_uv
                        vertex_copy_list[vertex_copy_index].mat         = vertex_mat
                        vertex_copy_index += 1
                    else:
                        # new copy vertex is not needed, but we need to use copy vertex already in the list
                        # this means that an existing copy vertex is shared between polygons
                        new_vertex_index = vertex_count + copy_index
                        polygon_list[polygon_index].vertices[polygon_vertex_index] = new_vertex_index
                else:
                    # new copy vertex is not needed, we can use the old polygon's vertex index
                    # this means that a regular vertex is shared between polygons
                    polygon_list[polygon_index].vertices[polygon_vertex_index] = vertex_index

    time_parse = time.clock() - time_parse
    
    time_write = time.clock()
    
    # save the model into a file
    # TODO: change this later to multiple file saving via resource file
    f = open( filepath, mode='wb')
    
    # write a placeholder for the header, which will be written last
    # when we know all the data locations in the file for sure
    # header size is always 64 bytes or 16 integers
    for i in range( 0, HEADER_SIZE_BYTES ):
        f.write( struct.pack( '<b', 0 ) )
    
    # clamp uv coordinates
    for v in vertex_list:
        v.uv = UVClamp( v.uv )
    for v in vertex_copy_list:
        v.uv = UVClamp( v.uv )
    
    # determine if we should invert the Y UV axis
    if uv_axis == 'TOP_LEFT':
        for v in vertex_list:
            v.uv[1] = -v.uv[1]
        for v in vertex_copy_list:
            v.uv[1] = -v.uv[1]
    
    # file data is saved in below loops
    file_loc_vertices = f.tell()
    for v in vertex_list:
        f.write( GetVertexPack( v ) )
    
    file_loc_copy_vertices = f.tell()
    for v in vertex_copy_list:
        f.write( GetVertexCopyPack( v ) )
    
    file_loc_polygons = f.tell()
    for p in polygon_list:
        f.write( GetPolygonPack( p ) )
    
    file_loc_end_padding = f.tell()
    f.write( struct.pack( '<2i', 0, 0 ) )
    
    # make sure this listing is up to date if changing any sizes
    vert_size       = len( GetVertexPack( Vertex() ) )
    vert_copy_size  = len( GetVertexCopyPack( VertexCopy() ) )
    poly_size       = len( GetPolygonPack( Polygon() ) )
    
    head                    = FileHeader()
    head.file_id            = STRING_ME3D
    head.head_size          = HEADER_SIZE_BYTES
    head.file_size          = f.tell()
    head.vert_count         = vertex_count
    head.vert_size          = vert_size
    head.vert_location      = file_loc_vertices
    head.copy_count         = len( vertex_copy_list )
    head.copy_size          = vert_copy_size
    head.copy_location      = file_loc_copy_vertices
    head.poly_count         = polygon_count
    head.poly_size          = poly_size
    head.poly_location      = file_loc_polygons
    
    f.seek( 0 )
    f.write( struct.pack( '<i', head.file_id ) )
    f.write( struct.pack( '<i', head.head_size ) )
    f.write( struct.pack( '<i', head.file_size ) )
    f.write( struct.pack( '<i', head.vert_count ) )
    f.write( struct.pack( '<i', head.vert_size ) )
    f.write( struct.pack( '<i', head.vert_location ) )
    f.write( struct.pack( '<i', head.copy_count ) )
    f.write( struct.pack( '<i', head.copy_size ) )
    f.write( struct.pack( '<i', head.copy_location ) )
    f.write( struct.pack( '<i', head.poly_count ) )
    f.write( struct.pack( '<i', head.poly_size ) )
    f.write( struct.pack( '<i', head.poly_location ) )
    f.close()
    
    time_write = time.clock() - time_write
    time_total = time.clock() - time_total
    
    if DEBUG_SHOW_MESSAGES:
        print( "--- Messages ---")
        print( "Unique Polygons:      " + str( len( polygon_list ) ) )
        print( "Unique Vertices:      " + str( len( vertex_list ) ) )
        print( "Copied Vertices:      " + str( len( vertex_copy_list ) ) )
        print( "--- Header data ---" )
        print( "head.file_id:         " + str( head.file_id ) )
        print( "head.head_size:       " + str( head.head_size ) )
        print( "head.file_size:       " + str( head.file_size ) )
        print( "head.vert_count:      " + str( head.vert_count ) )
        print( "head.vert_size:       " + str( head.vert_size ) )
        print( "head.vert_location:   " + str( head.vert_location ) )
        print( "head.copy_count:      " + str( head.copy_count ) )
        print( "head.copy_size:       " + str( head.copy_size ) )
        print( "head.copy_location:   " + str( head.copy_location ) )
        print( "head.poly_count:      " + str( head.poly_count ) )
        print( "head.poly_size:       " + str( head.poly_size ) )
        print( "head.poly_location:   " + str( head.poly_location ) )
        
    if DEBUG_CREATE_POINT_MESH:
        print( "--- Debug mesh created ---")
        db_mesh = bpy.data.meshes.new("TestMesh")
        db_obj = bpy.data.objects.new("TestObject", db_mesh)
        bpy.context.scene.objects.link( db_obj )
        
        db_point_list = []
        for copy in vertex_copy_list:
            db_point_list.append(mesh.vertices[copy.copyfrom].co)
        
        db_mesh.from_pydata(db_point_list, [], [])
        db_mesh.update()
        
        bpy.ops.object.select_all(action='DESELECT')
        db_obj.select = True
        context.scene.objects.active = db_obj
    
    if DEBUG_SHOW_TIMES:
        print( "--- Times ---")
        print( "Total:      " + str( time_total ) )
        print( "Allocation: " + str( time_alloc ) )
        print( "Parse:      " + str( time_parse ) )
        print( "Write:      " + str( time_write ) )
    
    # cleanup
    context.scene.objects.unlink( copyobj )
    bpy.data.objects.remove( copyobj )
    bpy.data.meshes.remove( copymesh )
    bpy.data.meshes.remove( mesh )
    
    # reselect the objects we had when we began the operation
    for i in range( 0, len( previous_objects ) ):
        previous_objects[i].select  = True
    context.scene.objects.active    = previous_active_object
    
    print( "--- MESH EXPORTER END ---" )
    return SUCCESS


def ImportME3D():
    """ Import a ME3D mesh """
    # not implemented
    return FAILURE


def GetVertexPack( v ):
    # vertex is packed as loc (3 floats), norm (3 shorts), uv (2 shorts)
    l = v.location
    n = [ int( v.normal[0] * SHORT_CONVERT_VALUE ), int( v.normal[1] * SHORT_CONVERT_VALUE ), int( v.normal[2] * SHORT_CONVERT_VALUE ) ]
    u = [ int( v.uv[0] * SHORT_CONVERT_VALUE ), int( v.uv[1] * SHORT_CONVERT_VALUE ) ]
    m = v.mat
    pack = struct.pack( '<3f', l[0], l[1], l[2])        # write location
    pack += struct.pack( '<3h', n[0], n[1], n[2] )      # write normals
    pack += struct.pack( '<2h', u[0], u[1] )            # write uvs
    pack += struct.pack( '<1h', m )                     # write material index
    return pack

def GetVertexCopyPack( v ):
    # vertex copy is packed as copy index (1 int), uv (2 shorts)
    c = v.copyfrom
    u = [ int( v.uv[0] * SHORT_CONVERT_VALUE ), int( v.uv[1] * SHORT_CONVERT_VALUE ) ]
    m = v.mat
    pack = struct.pack( '<1i', c )                      # write vertex id to copy from
    pack += struct.pack( '<2h', u[0], u[1] )            # write uvs
    pack += struct.pack( '<1h', m )                     # write material index
    return pack

def GetPolygonPack( p ):
    # polygon is packed as indices (3 ints)
    v = p.vertices
    pack = struct.pack( '<3i', v[0], v[1], v[2] )       # write vertex indices
    return pack


def Clamp( value, lower_limit, upper_limit ):
    if value > upper_limit:
        value = upper_limit
    if value < lower_limit:
        value = lower_limit
    return value

def UVClamp( uv ):
    u = [0.0, 0.0]
    u[0] = Clamp( uv[0], 0, 1 )
    u[1] = Clamp( uv[1], 0, 1 )
    return u


def CheckNeedForCopy( index_size, v1, v2, tolerance ):
    for i in range( 0, index_size ):
        if abs( v1[i] - v2[i] ) > tolerance:
            return True
    return False
