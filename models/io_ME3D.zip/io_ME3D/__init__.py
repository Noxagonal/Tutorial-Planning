#!BPY

bl_info = {
    "name": "GrafGear ME3D Import-Export",
    "author": "Niko Kauppi (Niko40)",
    "version": (0, 1),
    "blender": (2, 75, 0),
    "location": "File > Import/Export > GrafGear ME3D (.me3d)",
    "description": "Save and load GrafGear ME3D files",
    "warning": "Experimental file format (Work in progress, export only)",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"
    }


import bpy

import imp

if "ME3D" in locals():
    imp.reload(ME3D)
from .ME3D import *

from bpy_extras.io_utils import ExportHelper


class ExportME3D_Operator(bpy.types.Operator, ExportHelper):
    """Export ME3D mesh function"""
    bl_idname = "export_mesh.me3d"
    bl_label = "Export ME3D"

    global SUCCESS
    global FAILURE

    # ExportHelper mixin class uses this
    filename_ext = ".me3d"

    filter_glob = bpy.props.StringProperty(
            default="*.me3d",
            options={'HIDDEN'},
            maxlen=255, )

    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    type_up_axis = bpy.props.EnumProperty(
            name="Up Axis",
            description="Choose which coordinate points upwards in your game world",
            items=(('+Z', "+Z up, Blender", "Blender uses this coordinate system, positive Z points up"),
                   ('+Y', "+Y up, Native OpenGL", "Native OpenGL window coordinates, positive Y points up"),
                   ('-Y', "-Y up, Native Vulkan", "Native Vulkan window coordinates, negative Y points up")),
            default='+Z',
            )

    type_uv_axis = bpy.props.EnumProperty(
            name="UV Origin",
            description="Choose which coordinate points upwards in your game world",
            items=(('BOTTOM_LEFT', "Bottom Left, OpenGL", "Blender and OpenGL use this coordinate system, UV 0x0 coordinate is Bottom Left"),
                   ('TOP_LEFT', "Top Left, Vulkan", "Vulkan uses this coordinate system, UV 0x0 coordinate is Top Left")),
            default='TOP_LEFT',
            )

    def execute(self, context):
        if ExportME3D( context, context.object, self.filepath, self.type_up_axis, self.type_uv_axis ) == SUCCESS:
            return {'FINISHED'}
        return {'FAILURE'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.prop(self, "type_up_axis")
        col.prop(self, "type_uv_axis")



# Registration

def menu_func_export(self, context):
    self.layout.operator(ExportME3D_Operator.bl_idname, text="Grafgear ME3D (.me3d)", icon='PLUGIN')

#def menu_func_import(self, context):
#    self.layout.operator(ImportME3D_Operator.bl_idname, text="Grafgear ME3D (.me3d)", icon='PLUGIN')


def register():
    bpy.utils.register_class(ExportME3D_Operator)
#    bpy.utils.register_class(ImportME3D_Operator)
    bpy.types.INFO_MT_file_export.append(menu_func_export)
#    bpy.types.INFO_MT_file_import.append(menu_func_import)


def unregister():
    bpy.utils.unregister_class(ExportME3D_Operator)
#    bpy.utils.unregister_class(ImportME3D_Operator)
    bpy.types.INFO_MT_file_export.remove(menu_func_export)
#    bpy.types.INFO_MT_file_import.remove(menu_func_import)

if __name__ == "__main__":
    register()
